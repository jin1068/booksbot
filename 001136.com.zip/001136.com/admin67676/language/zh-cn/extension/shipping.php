<?php
// Heading
$_['heading_title']     = '配送';

// Text
$_['text_success']      = '成功：您已修改配送!';
$_['text_list']         = '配送列表';

// Column
$_['column_name']       = '配送方法';
$_['column_status']     = '状态';
$_['column_sort_order'] = '排序';
$_['column_action']     = '管理';

// Error
$_['error_permission']  = '错误：您没有配送修改权限!';
$_['error_extension']   = '错误：扩展不存在!';
