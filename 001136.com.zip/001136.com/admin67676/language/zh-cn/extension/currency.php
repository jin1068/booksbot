<?php
// Heading
$_['heading_title']    = '货币汇率';

// Text
$_['text_success']     = '成功：您已修改货币汇率!';
$_['text_list']        = '汇率列表';

// Column
$_['column_name']      = '汇率名称';
$_['column_status']    = '状态';
$_['column_action']    = '管理';

// Error
$_['error_permission'] = '错误：您无权修改货币汇率!';
$_['error_extension']  = '错误：扩展不存在!';
