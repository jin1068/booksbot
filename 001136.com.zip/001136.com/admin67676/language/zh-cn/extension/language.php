<?php
// Heading
$_['heading_title']    = '语言';

// Text
$_['text_success']     = '成功：您修改了语言!';
$_['text_list']        = '语言列表';

// Column
$_['column_name']      = '语音名称';
$_['column_status']    = '状态';
$_['column_action']    = '管理';

// Error
$_['error_permission'] = '错误：您没有修改语言的权限!';
$_['error_extension']  = '错误：扩展不存在!';
