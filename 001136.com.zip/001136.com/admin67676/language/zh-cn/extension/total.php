<?php
// Heading
$_['heading_title']     = '费用计算';

// Text
$_['text_success']      = '成功：您已修改费用计算!';

// Column
$_['column_name']       = '费用计算';
$_['column_status']     = '状态';
$_['column_sort_order'] = '排序';
$_['column_action']     = '管理';

// Error
$_['error_permission']  = '错误：您没有费用计算修改权限!';
$_['error_extension']   = '错误：扩展不存在!';
