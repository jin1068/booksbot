<?php
// Heading
$_['heading_title']    = '其他';

// Text
$_['text_success']     = '成功：您已修改其他 扩展!';
$_['text_list']        = '其他列表';

// Column
$_['column_name']      = '其他名称';
$_['column_status']    = '状态';
$_['column_action']    = '管理';

// Error
$_['error_permission'] = '错误：您没有其他扩展修改权限!';
$_['error_extension']  = '错误：扩展不存在!';
