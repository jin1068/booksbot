<?php
// Heading
$_['heading_title']    = '验证码';

// Text
$_['text_success']     = '成功：您已修改验证码!';
$_['text_list']        = '验证码列表';

// Column
$_['column_name']      = '验证码名称';
$_['column_status']    = '状态';
$_['column_action']    = '管理';

// Error
$_['error_permission'] = '错误：您没有验证码修改权限!';
$_['error_extension']  = '错误：扩展不存在!';
