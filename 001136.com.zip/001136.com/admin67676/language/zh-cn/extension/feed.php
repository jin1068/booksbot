<?php
// Heading
$_['heading_title']    = '数据源';

// Text
$_['text_success']     = '成功：您已修改数据源!';
$_['text_list']        = '数据源列表';

// Column
$_['column_name']      = '商品数据源名称';
$_['column_status']    = '状态';
$_['column_action']    = '管理';

// Error
$_['error_permission'] = '错误：您没有数据源修改权限!';
$_['error_extension']  = '错误：扩展不存在!';
