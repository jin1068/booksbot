<?php
// Heading
$_['heading_title']    = '简体中文';

// Text
$_['text_headline']    = '简体中文';
$_['text_extension']   = '扩展';
$_['text_success']     = '成功：你修改了中国语言!';
$_['text_edit']        = '编辑中国语言';
$_['text_translation'] = '翻译';
$_['text_version']     = '版本';
$_['language_version'] = 'V4.0.2.1';
$_['text_translator']  = 'sunny';
$_['text_improfment']  = '';

// Entry
$_['entry_status']     = '状态';
$_['entry_frontend']   = '前端';
$_['entry_stores']     = '商店';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告：您无权修改简体中文!';
