<?php
// Text
$_['text_subject']       = '%s - 退货更新 %s';
$_['text_return_id']     = '退货 ID';
$_['text_date_added']    = '退货日期';
$_['text_return_status'] = '您的退货状态已更新';
$_['text_comment']       = '附言：';
$_['text_footer']        = '如果您有任何问题请回复此电子邮件。';
