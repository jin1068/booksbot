<?php
// Text
$_['text_subject'] = '%s - GDPR请求已批准!';
$_['text_request'] = '账户删除请求';
$_['text_hello']   = '您好 <strong>%s</strong>,';
$_['text_user']    = '用户';
$_['text_gdpr']    = '您的GDPR数据删除请求已获得批准，将在<strong>%s 天</strong>内删除 .';
$_['text_q']       = 'Q. 为什么我们不立即删除您的数据?';
$_['text_a']       = 'A. 帐户删除请求将在 <strong>%s 天</strong>之后处理, 可以处理退款或欺诈检测.';
$_['text_delete']  = '当您的帐户被删除时，您将收到一封电子邮件通知您.';
$_['text_thanks']  = '谢谢,';
