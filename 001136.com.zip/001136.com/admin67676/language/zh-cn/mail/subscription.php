<?php
// Text
$_['text_subject']             = '%s - 订阅';
$_['text_subscription_id']     = '订阅 ID';
$_['text_date_added']          = '订阅日期:';
$_['text_subscription_status'] = '你的订阅 已添加到以下状态:';
$_['text_comment']             = '您订阅的是：:';
$_['text_payment_method']      = '付款方式';
$_['text_payment_code']        = '支付代码';
$_['text_footer']              = '如果您有任何问题，请回复此电子邮件.';
