<?php
// Text
$_['text_subject']   = '%s - GDPR请求已处理！';
$_['text_request']   = '账户删除请求';
$_['text_hello']     = '您好 <strong>%s</strong>,';
$_['text_user']      = '用户';
$_['text_delete']    = '您的GDPR数据删除请求现已完成.';
$_['text_contact']   = '有关更多信息，您可以在此处联系店主:';
$_['text_thanks']    = '谢谢,';

// Button
$_['button_contact'] = '联系我们';
