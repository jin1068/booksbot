<?php
// Text
$_['text_subject']   = '%s - 您的账户未审核通过！';
$_['text_welcome']   = '感谢您在 %s 注册账号！';
$_['text_denied']    = '非常抱歉，您的账户没有通过审核。请通过以下方式联系我们了解详细原因：';
$_['text_thanks']    = '感谢使用';

// Button
$_['button_contact'] = '联系我们 ';
