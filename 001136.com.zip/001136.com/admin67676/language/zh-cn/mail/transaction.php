<?php
// Text
$_['text_subject']  = '%s - 余额';
$_['text_received'] = '您收到 %s 余额！';
$_['text_total']    = '您的总余额为：%s';
$_['text_credit']   = '您的余额可在下次购物时抵消订单金额。';
