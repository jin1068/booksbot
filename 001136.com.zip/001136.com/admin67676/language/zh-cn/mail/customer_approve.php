<?php
// Text
$_['text_subject'] = '%s - 您的账号已激活！';
$_['text_welcome'] = '感谢您在 %s 注册账号！';
$_['text_login']   = '您的账号已激活，请使用您的邮件地址通过以下链接访问网站：';
$_['text_service'] = '登录后，您可以使用更多功能，如查看历史订单，打印发票及修改账号信息等。';
$_['text_thanks']  = '感谢使用';

// Button
$_['button_login']    = '登录';
