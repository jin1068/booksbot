<?php
// Text
$_['text_subject']  = '%s - 密码重置请求';
$_['text_greeting'] = '管理员 %s 请求了新密码。';
$_['text_change']   = '请点击以下链接重设密码：';
$_['text_ip']       = '请求 IP 地址：%s';
