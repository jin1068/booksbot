<?php
// Text
$_['text_subject'] = '尝试重置安全代码';
$_['text_reset']   = '有些人错误输入安全码超过3次.';
$_['text_link']    = '单击下面的链接重置帐户安全:';
$_['text_ip']      = 'IP:';
$_['text_regards'] = '最好的问候';
