<?php
// Text
$_['text_subject']  = '%s - 奖励积分';
$_['text_received'] = '您获得了 %s 点奖励积分！';
$_['text_total']    = '您的可用积分总数为：%s.';
