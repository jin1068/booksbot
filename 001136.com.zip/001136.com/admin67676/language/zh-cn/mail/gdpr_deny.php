<?php
// Text
$_['text_subject']   = '%s - GDPR请求被拒绝!';
$_['text_export']    = '帐户导出数据请求';
$_['text_remove']    = '账户删除请求';
$_['text_hello']     = '您好 <strong>%s</strong>,';
$_['text_user']      = '用户';
$_['text_contact']   = '很遗憾，您的请求被拒绝了。有关更多信息，您可以在此处联系商店:';
$_['text_thanks']    = '信息,';

// Button
$_['button_contact'] = '联系我们';
