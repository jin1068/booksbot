<?php
// Text
$_['text_subject'] = '%s - 您的联盟账号未审核通过！';
$_['text_welcome'] = '感谢您在 %s 注册账号！';
$_['text_denied']  = '很抱歉，您的联盟账号没有审核通过。请通过以下方式联系我们了解详细原因：';
$_['text_thanks']  = '感谢使用，';
