<?php
// Heading
$_['heading_title']          = 'OpenCart';

// Text
$_['text_notification']      = '通知';
$_['text_notification_all']  = '全部显示';
$_['text_notification_none'] = '没有通知';
$_['text_profile']           = '账号信息';
$_['text_store']             = '网店名称';
$_['text_help']              = '帮助';
$_['text_homepage']          = '技术支持';
$_['text_support']           = '技术论坛';
$_['text_documentation']     = '支持文档';
$_['text_logout']            = '退出登录';
