<?php
// Text
$_['text_footer']  = 'OpenCart &copy; 2009-' . date('Y') . ' 版权所有';
$_['text_version'] = '版本号 %s';
