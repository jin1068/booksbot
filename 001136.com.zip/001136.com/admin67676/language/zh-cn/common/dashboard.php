<?php
// Heading
$_['heading_title'] = '控制面板';
