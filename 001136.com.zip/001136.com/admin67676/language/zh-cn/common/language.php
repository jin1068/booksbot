<?php
$_['error_language'] = '错误：找不到语言!';
