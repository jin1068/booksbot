<?php
// Error
$_['error_extension'] = 'Warnung: Zahlungs-Methoden Erweiterung konnte nicht gefunden werden!';
$_['error_recurring'] = 'Warnung: Zahlungs-Methode hat keine wiederkehrende Zahlungs-Methode!';
$_['error_payment']   = 'Warnung: Zahlungs-Methode %s konnte nicht gefunden werden!';
