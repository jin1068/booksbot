<?php
// Text
$_['text_subject'] = '%s - Your affiliate account has been denied!';
$_['text_welcome'] = 'Welcome and thank you for registering at %s!';
$_['text_denied']  = 'Unfortunately your request has been denied. For more information you can contact the store owner here:';
$_['text_thanks']  = 'Thanks,';
