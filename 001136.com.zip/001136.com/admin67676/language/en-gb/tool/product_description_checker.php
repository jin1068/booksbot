<?php
// Heading
$_['heading_title']    = 'Product Description Checker';

// Text
$_['text_success']     = 'Success: Product descriptions have been updated!';
$_['text_list']        = 'Product List';

// Entry
$_['entry_product']    = 'Product';
$_['entry_description'] = 'Description';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify product descriptions!';

