<?php
// Text
$_['text_recommended'] = 'Recommended';
$_['text_install']     = 'Install';
$_['text_uninstall']   = 'Uninstall';
$_['text_delete']      = 'Delete';
