<?php
// Heading
$_['heading_title']    = 'Other';

// Text
$_['text_success']     = 'Success: You have modified other extension!';
$_['text_list']        = 'Other List';

// Column
$_['column_name']      = 'Other Name';
$_['column_status']    = 'Status';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify other extension!';
$_['error_extension']  = 'Warning: Extension does not exist!';
