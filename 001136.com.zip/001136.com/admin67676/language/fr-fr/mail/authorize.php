<?php
// Texte
$_['text_subject'] = 'Sécurité';
$_['text_code']    = 'Vous devez saisir le code de sécurité dans la vérification de sécurité de l\'administrateur.';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Cordialement';
