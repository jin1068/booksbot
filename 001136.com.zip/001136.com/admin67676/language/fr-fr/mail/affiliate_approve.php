<?php
// Texte
$_['text_subject']  = '%s - Votre compte affilié a été activé!';
$_['text_welcome']  = 'Bienvenue et merci de vous être inscrit sur %s!';
$_['text_login']    = 'Votre compte a maintenant été approuvé et vous pouvez vous connecter en utilisant votre adresse e-mail et votre mot de passe en visitant notre site Web ou à l\'URL suivante:';
$_['text_service']  = 'Une fois connecté, vous pourrez générer des codes de suivi, suivre les paiements de commission et modifier les informations de votre compte.';
$_['text_thanks']   = 'Merci,';
