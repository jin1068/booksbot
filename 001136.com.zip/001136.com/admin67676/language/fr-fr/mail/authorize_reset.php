<?php
// Texte
$_['text_subject'] = 'Réinitialiser les tentatives de code de sécurité';
$_['text_reset']   = 'Quelqu\'un a saisi le code de sécurité de manière incorrecte plus de 3 fois.';
$_['text_link']    = 'Cliquez sur le lien ci-dessous pour réinitialiser la sécurité du compte:';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Cordialement';
