<?php
// Erreur
$_['error_language'] = 'Attention: La langue n\'a pas pu être trouvée!';
