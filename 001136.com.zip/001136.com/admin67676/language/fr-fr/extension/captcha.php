<?php
// En-tête
$_['heading_title']    = 'Captchas';

// Texte
$_['text_success']     = 'Succès: Vous avez modifié les captchas!';
$_['text_list']        = 'Liste des Captchas';

// Colonne
$_['column_name']      = 'Nom du Captcha';
$_['column_status']    = 'Statut';
$_['column_action']    = 'Action';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas l\'autorisation de modifier les captchas!';
$_['error_extension']  = 'Attention: L\'extension n\'existe pas!';
